﻿angular.module("umbraco").controller("Test.Extension.Controller",
    function ($scope, $http, $injector, $routeParams, notificationsService, editorService, appState, eventsService) {
        // Get settings

        

    });
